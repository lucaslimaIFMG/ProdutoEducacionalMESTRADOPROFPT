using JornadaHeroica.Api.Models;
using JornadaHeroica.Api.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace JornadaHeroica.Api.Controllers
{
    /// <summary>
    /// Controlador responsável por receber mensagens do webhook
    /// e encaminhá-las para o serviço de conversação.
    /// </summary>
    [ApiController]
    [Route("[controller]")]
    public class WebhookController : ControllerBase
    {
        private readonly IConversationService _service;

        /// <summary>
        /// Inicializa uma nova instância do <see cref="WebhookController"/>.
        /// </summary>
        /// <param name="service">Serviço responsável por processar a conversação.</param>
        public WebhookController(IConversationService service)
        {
            _service = service;
        }

        /// <summary>
        /// Recebe uma mensagem enviada pelo webhook do WAHA,
        /// processa a conversação e retorna a resposta gerada.
        /// </summary>
        /// <param name="evt">Evento recebido do webhook.</param>
        /// <returns>
        /// Resultado HTTP contendo a resposta processada da conversação.
        /// </returns>
        [HttpPost]
        [Consumes("application/json")]
        [Produces("application/json")]
        public async Task<IActionResult> ReceiveMessage([FromBody] WahaWebhookEvent evt)
        {
            var response = await _service.ProcessEventAsync(evt);
            return Ok(response);
        }
    }
}
