using ClosedXML.Excel;
using JornadaHeroica.Api.Models;
using Microsoft.Extensions.Caching.Memory;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace JornadaHeroica.Api.Services
{
    public class ConversationService : IConversationService
    {
        private readonly IMemoryCache _cache;
        private readonly ConversationGraph _graph;

        public static readonly Dictionary<int, string> MonitoriaCsvLinks = new()
        {
            [1] = "https://docs.google.com/spreadsheets/d/1vp4MwItDT9qihr-86GjzuX7L1cxBRKCX/export?format=xlsx",
            [2] = "https://docs.google.com/spreadsheets/d/10iwrqggBskAGey7JFpf8HxjdJahIT7Ju/export?format=xlsx",
            [3] = "https://docs.google.com/spreadsheets/d/1rb-4eS3MpoUtnHds-YwVF46QI-oKEGYF/export?format=xlsx",
        };

        public static readonly IList<string> EditaisCsvLinks =
        [
            "https://docs.google.com/spreadsheets/d/1o7ITR-to50ybH2Ja9wor-SrKliGQiJaD/export?format=xlsx",
            "https://docs.google.com/spreadsheets/d/1O1MfBi_ovbQlq7JXE-b40wwn59rC2QOW/export?format=xlsx"
        ];

        public ConversationService(IMemoryCache cache, ConversationGraph graph)
        {
            _cache = cache;
            _graph = graph;
        }

        /// <summary>
        /// Processa um evento recebido do webhook do WAHA, gerenciando o estado da conversa,
        /// determinando a próxima resposta com base no grafo de conversação e enviando a resposta
        /// ao usuário via API do WAHA.
        /// </summary>
        /// <param name="evt">Evento recebido do webhook contendo os dados da mensagem.</param>
        /// <returns>
        /// Objeto dinâmico representando a resposta da API do WAHA, ou <c>null</c> caso não haja conteúdo.
        /// </returns>
        public async Task<dynamic?> ProcessEventAsync(WahaWebhookEvent evt)
        {
            var wahaApiUrl = Environment.GetEnvironmentVariable("WAHA_API_URL") ?? "http://portainer.lan:5330";
            var stateExists = _cache.TryGetValue(evt.Payload!.From!, out ConversationState? state);

            var historyKey = $"{evt.Payload.From!}_history";
            if (!_cache.TryGetValue(historyKey, out List<string>? history))
            {
                history = [];
            }

            if (!stateExists)
            {
                var startNode = _graph["start"];
                state = new ConversationState { CurrentNode = "start" };
                _cache.Set(evt.Payload.From!, state);

                history!.Add(startNode.Text);
                _cache.Set(historyKey, history, new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1)
                });

                var clientInit = new RestClient(wahaApiUrl);
                var requestInit = new RestRequest("/api/sendText", Method.Post);
                requestInit.AddJsonBody(new { session = "default", chatId = evt.Payload.From, text = startNode.Text });

                var responseInit = await clientInit.ExecuteAsync(requestInit);
                Console.WriteLine($"{responseInit.StatusCode} - {responseInit.Content}");

                if (string.IsNullOrEmpty(responseInit.Content))
                {
                    return null;
                }

                var startResponse = JsonSerializer.Deserialize<dynamic>(responseInit.Content);
            }

            if (!_graph.TryGetValue(state!.CurrentNode, out var node))
            {
                state.CurrentNode = "start";
                node = _graph[state.CurrentNode];
            }

            string reply;

            if (!string.IsNullOrEmpty(node.Next))
            {
                if (_graph.TryGetValue(node.Next, out var targetNode))
                {
                    if (state.CurrentNode == "historico")
                    {
                        state.RA = evt.Payload.Body!.Trim();
                        reply = $"Acesse o link abaixo para solicitação de histórico:\n\n" + $"https://suap.ifmg.edu.br/edu/aluno/{state.RA}/?tab=boletim";
                    }
                    else
                    {
                        reply = targetNode.Text;
                    }

                    state.CurrentNode = node.Next;
                }
                else
                {
                    state.CurrentNode = "start";
                    reply = _graph["start"].Text;
                }
            }
            else if (node.Options.Count > 0)
            {
                if (node.Options.TryGetValue(evt.Payload.Body!, out var nextNodeKey) && _graph.TryGetValue(nextNodeKey, out var targetNode))
                {
                    if (node == _graph["serie"])
                    {
                        if (int.TryParse(evt.Payload.Body, out int ano))
                        {
                            state.Ano = ano;
                        }
                    }

                    if (nextNodeKey == "monitorias")
                    {
                        reply = await ObterMonitoriasAsync(state.Ano);
                    }
                    else if (nextNodeKey is "editais")
                    {
                        reply = await ObterEditaisAsync();
                    }
                    else
                    {
                        reply = targetNode.Text;
                    }

                    state.CurrentNode = nextNodeKey;
                }
                else
                {
                    reply = "Opção inválida. Tente novamente.";
                }
            }
            else
            {
                reply = node.Text;
            }

            _cache.Set(evt.Payload.From!, state, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10)
            });

            Console.WriteLine($"NextNode: {state.CurrentNode}");

            history!.Add(reply);
            _cache.Set(historyKey, history, new MemoryCacheEntryOptions
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1)
            });

            var client = new RestClient(wahaApiUrl);
            var request = new RestRequest("/api/sendText", Method.Post);
            request.AddJsonBody(new { session = "default", chatId = evt.Payload.From, text = reply });

            var response = await client.ExecuteAsync(request);
            Console.WriteLine($"{response.StatusCode} - {response.Content}");

            if (string.IsNullOrEmpty(response.Content))
            {
                return null;
            }

            return JsonSerializer.Deserialize<dynamic>(response.Content);
        }

        /// <summary>
        /// Obtém a lista de monitorias para um determinado ano a partir de uma planilha XLSX
        /// e monta a mensagem formatada para envio ao usuário.
        /// </summary>
        /// <param name="ano">Ano da série para buscar as monitorias.</param>
        /// <returns>
        /// Texto formatado contendo as monitorias encontradas ou uma mensagem de erro/aviso.
        /// </returns>
        public static async Task<string> ObterMonitoriasAsync(int ano)
        {
            if (!MonitoriaCsvLinks.TryGetValue(ano, out var url))
            {
                return "⚠️ Não encontrei a planilha de monitorias para seu ano.\n0 Voltar ao menu anterior";
            }

            try
            {
                var tabela = await LerXlsxParaDataTableAsync(url);
                return MontarMensagemMonitorias(tabela);
            }
            catch (Exception ex)
            {
                return $"Erro ao ler monitorias: {ex.Message}\n\n0 Voltar ao menu anterior";
            }
        }

        /// <summary>
        /// Obtém a lista de editais a partir da planilha XLSX configurada
        /// e monta a mensagem formatada para envio ao usuário.
        /// </summary>
        /// <returns>
        /// Texto formatado contendo os editais encontrados ou uma mensagem de erro.
        /// </returns>
        private async Task<string> ObterEditaisAsync()
        {
            try
            {
                var tabela = await LerXlsxParaDataTableAsync(EditaisCsvLinks[1]);
                //var linhasFiltradas = tabela.AsEnumerable().Where(r => string.Equals(r["Tipo"]?.ToString(), tipo, StringComparison.OrdinalIgnoreCase)).CopyToDataTable();
                return MontarMensagemEditais(tabela);
            }
            catch (Exception ex)
            {
                return $"Erro ao ler monitorias: {ex.Message}\n\n0 Voltar ao menu anterior";
            }
        }

        /// <summary>
        /// Lê um arquivo XLSX a partir de uma URL e converte a primeira planilha em um <see cref="DataTable"/>.
        /// A primeira linha é considerada como cabeçalho das colunas.
        /// </summary>
        /// <param name="xlsxUrl">URL pública do arquivo XLSX.</param>
        /// <returns>
        /// <see cref="DataTable"/> contendo os dados da planilha.
        /// </returns>
        private static async Task<DataTable> LerXlsxParaDataTableAsync(string xlsxUrl)
        {
            using var client = new HttpClient();
            var bytes = await client.GetByteArrayAsync(xlsxUrl);

            using var stream = new MemoryStream(bytes);
            using var workbook = new XLWorkbook(stream);

            // Vamos assumir que a primeira planilha contém os dados
            var worksheet = workbook.Worksheets.Worksheet(1);
            var tabela = new DataTable();

            bool primeiraLinha = true;

            foreach (var row in worksheet.RowsUsed())
            {
                if (primeiraLinha)
                {
                    // Cabeçalhos
                    foreach (var cell in row.CellsUsed())
                    {
                        tabela.Columns.Add(cell.GetString().Trim());
                    }
                    primeiraLinha = false;
                }
                else
                {
                    var dataRow = tabela.NewRow();
                    int i = 0;
                    foreach (var cell in row.Cells(1, tabela.Columns.Count))
                    {
                        dataRow[i++] = cell.GetValue<string>().Trim();
                    }
                    tabela.Rows.Add(dataRow);
                }
            }

            return tabela;
        }

        /// <summary>
        /// Monta a mensagem de resposta contendo as informações de monitorias
        /// a partir de um <see cref="DataTable"/>.
        /// </summary>
        /// <param name="tabela">Tabela com os dados das monitorias.</param>
        /// <returns>
        /// Texto formatado pronto para envio ao usuário.
        /// </returns>
        private static string MontarMensagemMonitorias(DataTable tabela)
        {
            var sb = new StringBuilder();
            sb.AppendLine("📘 *Monitorias:*\n");

            foreach (DataRow row in tabela.Rows)
            {
                sb.AppendLine($"📚 *{row["Disciplina"]}*");

                if (!string.IsNullOrWhiteSpace(row["Monitor(a)"].ToString()))
                {
                    sb.AppendLine($"👤 *Monitor(a):* {row["Monitor(a)"]}");
                }

                if (!string.IsNullOrWhiteSpace(row["Orientador"].ToString()))
                {
                    sb.AppendLine($"👨‍🏫 *Orientador:* {row["Orientador"]}");
                }

                sb.AppendLine($"🗓️ *Dias:* {row["Dia(s) da Semana"]}");
                sb.AppendLine($"⏰ *Horário:* {row["Horário"]}");
                sb.AppendLine($"📍 *Local:* {row["Local - Prédio II"]}");
                sb.AppendLine();
            }

            return sb.ToString().TrimEnd();
        }

        /// <summary>
        /// Monta a mensagem de resposta contendo as informações de editais
        /// a partir de um <see cref="DataTable"/>.
        /// </summary>
        /// <param name="tabela">Tabela com os dados dos editais.</param>
        /// <returns>
        /// Texto formatado pronto para envio ao usuário.
        /// </returns>
        private static string MontarMensagemEditais(DataTable tabela)
        {
            var sb = new StringBuilder();
            sb.AppendLine("📑 *Editais Disponíveis:*\n");

            foreach (DataRow row in tabela.Rows)
            {
                sb.AppendLine($"📌 *{row["Nome do Edital"]}* ({row["Ano"]})");
                sb.AppendLine($"📂 *Tipo:* {row["Tipo"]}");
                sb.AppendLine($"🔗 *Site/Formulário:* {row["Site ou formulario"]}");
                sb.AppendLine($"📄 *PDF:* {row["Link pdf"]}");
                sb.AppendLine($"📊 *Status:* {row["Status"]}");

                if (tabela.Columns.Contains("Contato"))
                {
                    var contato = row["Contato"]?.ToString();
                    if (!string.IsNullOrWhiteSpace(contato))
                    {
                        sb.AppendLine($"📞 *Contato:* {contato}");
                    }
                }

                sb.AppendLine();
            }

            return sb.ToString().TrimEnd();
        }
    }
}
