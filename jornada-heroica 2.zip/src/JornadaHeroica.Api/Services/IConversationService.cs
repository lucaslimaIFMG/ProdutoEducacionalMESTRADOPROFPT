using JornadaHeroica.Api.Models;
using System.Threading.Tasks;

namespace JornadaHeroica.Api.Services
{
    public interface IConversationService
    {
        Task<dynamic?> ProcessEventAsync(WahaWebhookEvent evt);
    }
}
