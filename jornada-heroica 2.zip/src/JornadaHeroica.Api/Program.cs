using JornadaHeroica.Api.Models;
using JornadaHeroica.Api.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Text;

Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
//Environment.SetEnvironmentVariable("ASPNETCORE_URLS", "http://localhost:5019");

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddOpenApi();
builder.Services.AddMemoryCache();

var conversationGraph = builder.Configuration.GetSection("ConversationGraph").Get<ConversationGraph>();
if (conversationGraph != null)
{
    builder.Services.AddSingleton(conversationGraph);
    builder.Services.AddScoped<IConversationService, ConversationService>();
}

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseAuthorization();
app.MapControllers();

app.Run();
