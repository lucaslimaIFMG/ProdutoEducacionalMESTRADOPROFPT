using System.Collections.Generic;

namespace JornadaHeroica.Api.Models
{
    /// <summary>
    /// Representa o grafo de conversação, onde cada chave identifica um nó
    /// e o valor corresponde à definição do nó da conversa.
    /// </summary>
    public class ConversationGraph : Dictionary<string, ConversationNode>;
}
