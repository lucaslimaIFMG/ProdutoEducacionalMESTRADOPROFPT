namespace JornadaHeroica.Api.Models
{
    /// <summary>
    /// Armazena o estado atual da conversa de um usuário,
    /// incluindo o nó atual, RA informado e o ano selecionado.
    /// </summary>
    public class ConversationState
    {
        public required string CurrentNode { get; set; }

        public string? RA { get; set; }

        public int Ano { get; set; }
    }
}
