namespace JornadaHeroica.Api.Models
{
    public class WahaWebhookEvent
    {
        public string? Id { get; set; }
        public string? Session { get; set; }
        public string? Event { get; set; }
        public WahaWebhookPayload? Payload { get; set; }
        public long Timestamp { get; set; }
        public WahaWebhookMetadata? Metadata { get; set; }
        public WahaWebhookMe? Me { get; set; }
        public string? Engine { get; set; }
        public WahaWebhookEnvironment? Environment { get; set; }
    }

    public class WahaWebhookPayload
    {
        public string? Id { get; set; }
        public long Timestamp { get; set; }
        public string? From { get; set; }
        public bool FromMe { get; set; }
        public string? Source { get; set; }
        public string? To { get; set; }
        public string? Body { get; set; }
        public bool HasMedia { get; set; }
        public object? Media { get; set; }
        public int Ack { get; set; }
        public string? AckName { get; set; }
        public object? VCards { get; set; }
        public object? Data { get; set; }
    }

    public class WahaWebhookMetadata
    {
    }

    public class WahaWebhookMe
    {
        public string? Id { get; set; }
        public string? PushName { get; set; }
    }

    public class WahaWebhookEnvironment
    {
        public string? Version { get; set; }
        public string? Engine { get; set; }
        public string? Tier { get; set; }
        public string? Browser { get; set; }
    }
}
