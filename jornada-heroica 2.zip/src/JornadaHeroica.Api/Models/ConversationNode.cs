using System.Collections.Generic;

namespace JornadaHeroica.Api.Models
{
    /// <summary>
    /// Representa um nó da conversa, contendo o texto exibido ao usuário,
    /// a referência para o próximo nó e as opções disponíveis de navegação.
    /// </summary>
    public class ConversationNode
    {
        public required string Text { get; set; }

        public string? Next { get; set; }

        public Dictionary<string, string> Options { get; set; } = [];
    }
}
